package com.sprk.voting.service;

import java.util.Collection;
import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.sprk.voting.model.UserDTO;
import com.sprk.voting.model.UserModel;

public interface UserService extends UserDetailsService{
    
    UserModel saveUser(UserModel userModel);

    void removeSessionMsg();
    
    UserModel getUserByEmail(String userEmail);

    Collection<UserModel> getAllUser();

    void updateUser(UserModel userModel);

    UserModel updateRole(UserModel userModel);

    UserModel findUserById(int userId);

    UserDTO getUserByUserId(int userId);

    List<UserModel> getAllUsers();

    void deleteUser(UserModel userModel);
}


