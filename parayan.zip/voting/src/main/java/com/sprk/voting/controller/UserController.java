package com.sprk.voting.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import com.sprk.voting.model.UserModel;
import com.sprk.voting.service.UserService;
import jakarta.servlet.http.HttpSession;


@Controller
public class UserController {

  @Autowired
  private UserService userService;

  private static String uploadDir = "src/main/resources/static/resume";


@GetMapping("/user/register")
public String showUserForm(Model model, String attributeName){

    model.addAttribute("userObj", new UserModel());

    return "register";

  }
   
  @PostMapping("/user/register")
  public String saveUserForm(@valid @ModelAttribute("userObj") UserModel userModel, BindingResult bindingResult, HttpSession session, @RequestParam("fileData") MultipartFile file) throws Exception{

    String fileTitle="";

    if(bindingResult.hasErrors())
    
    {
      System.out.println("Inside Error method" + bindingResult.getAllErrors());
      return "register";

    }else{

          UserModel sessionUser = (UserModel)session.getAttribute("user");
      try {
        if (!file.isEmpty()) {
             fileTitle = (userModel.getUserPhone() + file.getOriginalFilename());
            Path fileNameAndPath = Paths.get(uploadDir, fileTitle);
            System.out.println("Inside try block");

            // Create directories if they do not exist
           // Files.createDirectories(fileNameAndPath.getParent());

            Files.write(fileNameAndPath, file.getBytes());

            userModel.setMyfile(fileTitle);
            
        }

        UserModel savedUser = userService.saveUser(userModel);

        if (savedUser != null) {
            session.setAttribute("msg", "Data saved successfully");
        } else {
            session.setAttribute("msg", "Error in server");
        }

    } catch (IOException e) {
        session.setAttribute("msg", "File upload error: " + e.getMessage());
        e.printStackTrace();
    }

    return "redirect:/user/showLoginForm";
}
}



@GetMapping("/user/profile")
    public String showUserDashboard(Model model, HttpSession session) {

        UserModel sessionUser = (UserModel) session.getAttribute("user");
      //  UserDTO userDTO = userService.getUserByUserId(sessionUser.getUserId());
        if (sessionUser == null) {
            session.setAttribute("msg", "User not found!!");
            return "redirect:/user/showLoginForm";
        }
        model.addAttribute("userObj", sessionUser);

        return "user_dashboard";
      }

     

}

