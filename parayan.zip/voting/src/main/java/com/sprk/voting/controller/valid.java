package com.sprk.voting.controller;

public @interface valid {

}
