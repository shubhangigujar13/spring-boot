package com.sprk.voting.service;

public class RoleServiceImpl implements RoleSevice{

}
