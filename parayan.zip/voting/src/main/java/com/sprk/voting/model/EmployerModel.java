package com.sprk.voting.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.ToString;

@Entity
@Data
@ToString
public class EmployerModel {

    
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private int employerId;

  
    @NotBlank(message = "User Name Should not be null")
    private String employerName;

    @NotBlank(message = "Please write valied email id")
    private String employerEmail;

    @NotBlank(message = "Please Enter Your Valied Phone Number")
    private String employerPhone;

    @NotBlank(message = "Please Enter Company Name")
    private String companyName;

    @NotBlank(message = "Please Enter Number Of Vacancies")
    private String noOfVacancies;

    @NotBlank(message = "Please Mention The Post Name(Job Role)")
    private String postName;

    @NotBlank(message = "Please Enter the Correct Location")
    private String companyLocation;

    private String details;
       

}



