package com.sprk.voting.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sprk.voting.model.RoleModel;

public interface RoleRepository extends JpaRepository<RoleModel, Integer> {
    
    List<RoleModel> findByName(String name);

}
