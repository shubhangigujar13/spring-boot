package com.sprk.voting.controller;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


import com.sprk.voting.model.EmployerModel;
import com.sprk.voting.model.UserModel;
import com.sprk.voting.service.EmployerServices;

import com.sprk.voting.service.UserService;



@Controller

public class AdminController {

    @Autowired
    private UserService userService;

    @Autowired
    private EmployerServices employerServices;
    
    @GetMapping("/admin/listusers")
    public String getAllUser(Model model){

        Collection<UserModel> allUsers = userService.getAllUser();
        model.addAttribute("allUsers", allUsers);

        List<EmployerModel> allEmployer = employerServices.getAllEmployer();
        model.addAttribute("allEmployer", allEmployer);

        return "admin_dashboard";

}

     

}
