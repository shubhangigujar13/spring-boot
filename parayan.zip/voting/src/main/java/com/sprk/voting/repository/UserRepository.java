package com.sprk.voting.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sprk.voting.model.UserModel;

@Repository
public interface UserRepository extends JpaRepository<UserModel, Integer> {

    UserModel findByUserEmail(String userName);

   
     @Modifying
    @Query("UPDATE UserModel set userName = :userName, userEmail = :userEmail, userPhone =:userPhone, myfile =:resume  WHERE userId =:userId")
    void updateUserProfile(int userId, String userName, String userEmail, String userPhone, String resume);

   

}
