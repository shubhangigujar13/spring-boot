package com.sprk.voting.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sprk.voting.model.EmployerModel;

public interface EmployerRepository  extends JpaRepository<EmployerModel, Integer>{

}
