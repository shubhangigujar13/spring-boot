package com.sprk.voting.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import com.sprk.voting.model.EmployerModel;
import com.sprk.voting.service.EmployerServices;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
public class EmployerController {

    @Autowired
    private EmployerServices employerServices;

   


    @PostMapping("/postJob")
    public String postJob(@Valid @ModelAttribute("employerObj") EmployerModel employerModel, BindingResult bindingResult)throws Exception {

     employerServices.saveEmployerModel(employerModel);
      
        
        return "redirect:/user/showLoginForm";
    }
    
}

