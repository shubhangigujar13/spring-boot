package com.sprk.voting.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import com.sprk.voting.model.RoleModel;
import com.sprk.voting.model.UserDTO;
import com.sprk.voting.model.UserModel;
import com.sprk.voting.repository.RoleRepository;
import com.sprk.voting.repository.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Service
public class UserServiceImpl implements UserService{
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Override
    public UserModel saveUser(UserModel userModel) {

      String encodedPassword = bCryptPasswordEncoder.encode(userModel.getUserPass());
     // System.out.println(encodedPassword);
      userModel.setUserPass(encodedPassword);
      List<RoleModel> roleModel= roleRepository.findByName("ROLE_USER");

      userModel.setRoles(roleModel);
      UserModel saveUser = userRepository.save(userModel);
      return saveUser;
    }

    @Override
    public void removeSessionMsg() {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpServletRequest request = attr.getRequest();
        HttpSession session = request.getSession();

        session.removeAttribute("msg");

    }

   

    @Override
    public UserModel getUserByEmail(String userEmail) {
      UserModel dbUserModel = userRepository.findByUserEmail(userEmail);
      return dbUserModel;
    }

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
      UserModel dbUserModel = userRepository.findByUserEmail(userName);
      if(dbUserModel !=null)
      {
        //System.out.println(dbUserModel.getRoles());
        Collection<SimpleGrantedAuthority> authorities = mapRolesToAuthorities(dbUserModel.getRoles());
        return new User(dbUserModel.getUserEmail(),dbUserModel.getUserPass(),authorities);
      }
      else{
      throw new UsernameNotFoundException("Invalid username or password");
      }
    }



    private Collection<SimpleGrantedAuthority>mapRolesToAuthorities(Collection<RoleModel> roles){

      Collection<SimpleGrantedAuthority> authorities = new ArrayList<>();
      for(RoleModel tempRole : roles){
        //System.out.println(tempRole.getName());
        SimpleGrantedAuthority authority = new SimpleGrantedAuthority((tempRole.getName()));
        authorities.add(authority);
      }
      return authorities;
    }

    @Override
    public Collection<UserModel> getAllUser() {
       return userRepository.findAll();
    }

    @Override
    public void updateUser(UserModel userModel) {
      int userId = userModel.getUserId();
      String userName = userModel.getUserName();
      String userEmail = userModel.getUserEmail();
      String userPhone = userModel.getUserPhone();
      String resume = userModel.getMyfile();
      userRepository.updateUserProfile(userId, userName, userEmail, userPhone, resume);
    }

    @Override
    public UserModel updateRole(UserModel userModel) {
      UserModel savedUser = userRepository.save(userModel);
        return savedUser;
    }

    @Override
    public UserModel findUserById(int userId) {
        Optional<UserModel> userModel = userRepository.findById(userId);
        if (userModel.isEmpty()) {

            return null;
        }
        UserModel dbModel = userModel.get();
        return dbModel;
    }

    @Override
    public UserDTO getUserByUserId(int userId) {
       Optional<UserModel> userModel = userRepository.findById(userId);
        if (userModel.isEmpty()) {

            return null;
        }
        UserModel dbModel = userModel.get();
        UserDTO userDTO = new UserDTO(dbModel.getUserId(), dbModel.getUserName(), dbModel.getUserEmail(), dbModel.getUserPass(), dbModel.getUserPhone(), dbModel.getMyfile());
        
        return userDTO;
    }

    @Override
    public List<UserModel> getAllUsers() {
      return userRepository.findAll();
    }

    @Override
    public void deleteUser(UserModel userModel) {
      userRepository.delete(userModel);
    }

   

}
