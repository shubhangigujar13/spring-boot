package com.sprk.voting.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.sprk.voting.model.EmployerModel;

public interface EmployerServices extends UserDetailsService {

     EmployerModel saveEmployerModel(EmployerModel employerModel);
     
     List<EmployerModel>getAllEmployer();
    
    
}
