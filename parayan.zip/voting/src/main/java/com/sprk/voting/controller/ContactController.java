package com.sprk.voting.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller
public class ContactController {

    @Autowired
    private JavaMailSender javaMailSender;

    @PostMapping("/send")
    public String sendEmail(@RequestParam("name") String name, @RequestParam("email") String email, @RequestParam("phone") String phone, @RequestParam("message") String message, RedirectAttributes redirectAttributes) {

        try {
            SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
            simpleMailMessage.setTo("parayanaenterprises@gmail.com");
            simpleMailMessage.setSubject("Contact Form Submission");
            simpleMailMessage.setText("Name: " + name + "\n"
                    + "Email: " + email + "\n\n"
                    + "Phone: " + phone + "\n\n"
                    + "Message:\n" + message);

            javaMailSender.send(simpleMailMessage);

            redirectAttributes.addFlashAttribute("successMessage", "Thank you for contacting us, " + name + "!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "There was an error sending your message. Please try again.");
        }

        return "redirect:/user/showLoginForm";
    }
}
    
    


