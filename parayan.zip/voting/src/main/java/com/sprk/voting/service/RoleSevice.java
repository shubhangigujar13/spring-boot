package com.sprk.voting.service;

public interface RoleSevice {

}
