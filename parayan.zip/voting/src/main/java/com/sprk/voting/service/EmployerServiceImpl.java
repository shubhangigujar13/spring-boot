package com.sprk.voting.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.sprk.voting.model.EmployerModel;
import com.sprk.voting.repository.EmployerRepository;

@Service
public class EmployerServiceImpl implements EmployerServices {

    @Autowired
    private EmployerRepository employerRepository;

    @Override
    public EmployerModel saveEmployerModel(EmployerModel employerModel) {
       
        return employerRepository.save(employerModel);
    }

    @Override
    public List<EmployerModel> getAllEmployer() {
       
        return employerRepository.findAll();
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
       
        throw new UnsupportedOperationException("Unimplemented method 'loadUserByUsername'");
    }


   

}
