package com.sprk.voting.configration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;

import com.sprk.voting.service.UserService;

@Configuration
@EnableWebSecurity
public class SpringSecurity {

    @Bean
    public BCryptPasswordEncoder encoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public DaoAuthenticationProvider daoAuthenticationProvider(UserService userService) {
        DaoAuthenticationProvider auth = new DaoAuthenticationProvider();
        auth.setUserDetailsService(userService);
        auth.setPasswordEncoder(encoder());
        return auth;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http, AuthenticationSuccessHandler customSuccess)
            throws Exception {

                

        http.authorizeHttpRequests(configurer -> configurer
        .requestMatchers("/", "/send", "/postJob").permitAll()
                .requestMatchers("/", "/css/**", "/images/**").permitAll()
                .requestMatchers("/user/showLoginForm", "/user/register", "/user/profile", "/error").permitAll()
                .requestMatchers("/user/**").hasRole("USER")
                .requestMatchers("/admin/**").hasRole("ADMIN")
                .anyRequest().authenticated());

           

            http.formLogin(form -> form
                .loginPage("/user/showLoginForm")
                .usernameParameter("email")
                .passwordParameter("password")
                .loginProcessingUrl("/authenticateUser")
                .defaultSuccessUrl("/user/profile").permitAll());
               // .successHandler(customSuccess).permitAll());
               
                

            http.logout(logout -> logout.permitAll());

            http.csrf(csrf -> csrf.disable());


            http.exceptionHandling(configurer -> configurer
                .accessDeniedPage("/accessdenied"));  

        return http.build();
    }
}
