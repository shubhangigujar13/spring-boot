package com.sprk.voting.model;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.ToString;

@Entity
@Data
@ToString
public class UserModel {

    
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private int userId;

  
    @NotBlank(message = "User Name Should not be null")
    private String userName;

    @NotBlank(message = "Please write valied email id")
    @Column(unique = true)
    private String userEmail;

    @Column(unique = true)
    @NotBlank(message = "Please Enter Your Correct Phone Number")
    private String userPhone;

    @NotBlank(message = "Password Should not be null")
    private String userPass;
    
    @NotBlank(message = "Please Upload Your Resume")
    @Column(unique = true)
    private String myfile;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "user_role", joinColumns = {@JoinColumn(name="user_id")}, inverseJoinColumns ={@JoinColumn(name="role_id")})
    private List<RoleModel> roles;



    

}
