package com.sprk.voting.configration;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import com.sprk.voting.model.RoleModel;
import com.sprk.voting.repository.RoleRepository;

@Component
public class DataLoader implements ApplicationRunner {

    @Autowired
    private RoleRepository roleRepository;

    @Override
    public void run(ApplicationArguments args) throws Exception {

       // RoleModel roleModel = roleRepository.findByName("ROLE_USER").getFirst();
        List<RoleModel>roleModel = roleRepository.findByName("ROLE_USER");

        if (roleModel.isEmpty()) {
            RoleModel roleModel2 = new RoleModel();
            roleModel2.setName("ROLE_USER");

            roleRepository.save(roleModel2);
        }

    }

}
